<div class="col-full handheld-only">
	<div class="handheld-header">
		<div class="row">
			
			<?php require 'logo.php'; ?>

			<?php require 'handheld-navbar-right.php'; ?>

		</div><!-- /.row -->
		
		<?php require 'handheld-sticky-wrapper.php'; ?>
		
	</div><!-- .handheld-header -->
</div><!-- .handheld-only -->
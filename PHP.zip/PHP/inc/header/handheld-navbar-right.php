<div class="handheld-header-links">
	<ul class="columns-3">
		<li class="my-account">
			<a href="index.php?page=login-and-register" class="has-icon">
				<i class="tm tm-login-register"></i>
			</a>
		</li>
		<li class="wishlist">
			<a href="index.php?page=wishlist" class="has-icon">
				<i class="tm tm-favorites"></i><span class="count">3</span>
			</a>
		</li>
		<li class="compare">
			<a href="index.php?page=compare" class="has-icon">
				<i class="tm tm-compare"></i><span class="count">3</span>
			</a>
		</li>
	</ul><!-- .columns-3 -->
</div><!-- .handheld-header-links -->
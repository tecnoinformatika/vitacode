<div class="top-bar top-bar-v9">
	<?php require 'top-bar-v2.php'; ?>
</div><!-- .top-bar-v2 -->

<header id="masthead" class="site-header header-v9" style="background-image: none; ">
	<div class="col-full desktop-only">
		<div class="techmarket-sticky-wrap">
			<div class="row">
				
				<?php require_once 'inc/header/sportsmarket-logo.php'; ?>

				<?php require_once 'inc/menu/primary-menu-2.php'; ?>

				<?php require_once 'inc/header/navbar-right.php'; ?>

			</div><!-- /.row -->
		</div><!-- /.techmarket-sticky-wrap -->
	</div><!-- .col-full -->
	
	<?php require_once 'inc/header/handheld-sports-header.php'; ?>

</header><!-- .site-header -->
<!-- ============================================================= Header End ============================================================= -->
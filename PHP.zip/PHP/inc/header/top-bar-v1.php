<div class="top-bar top-bar-v1">
	<div class="col-full">
		<ul id="menu-top-bar-left" class="nav justify-content-center">
			<li class="menu-item animate-dropdown">
				<a title="TechMarket eCommerce - Always free delivery" href="index.php?page=contact-v1">TechMarket eCommerce &#8211; Always free delivery</a>
			</li>
			<li class="menu-item animate-dropdown">
				<a title="Quality Guarantee of products" href="index.php?page=shop">Quality Guarantee of products</a>
			</li>
			<li class="menu-item animate-dropdown">
				<a title="Fast returnings program" href="index.php?page=track-your-order">Fast returnings program</a>
			</li>
			<li class="menu-item animate-dropdown">
				<a title="No additional fees" href="index.php?page=contact-v2">No additional fees</a>
			</li>
		</ul><!-- .nav -->
	</div><!-- .col-full -->
</div><!-- .top-bar-v1 -->
<header id="masthead" class="site-header header-v8" style="background-image: none; ">
	<div class="col-full desktop-only">
		<div class="techmarket-sticky-wrap">
			<div class="row">

				<?php require_once 'inc/header/shoesmarket-logo.php'; ?>

				<?php require_once 'inc/menu/primary-menu.php'; ?>

				<?php require_once 'inc/header/navbar-right.php'; ?>
			</div><!-- /.row -->

		</div><!-- /.techmarket-sticky-wrap -->
	</div><!-- .col-full -->
	
	<?php require_once 'inc/header/handheld-shoes-header.php'; ?>

</header> <!-- .header-v8 -->
<!-- ============================================================= Header End ============================================================= -->
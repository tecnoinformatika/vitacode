<footer class="site-footer footer-v1">
	<div class="col-full">
		<?php require_once 'inc/footer/footer-top-row.php'; ?>

		<div class="footer-widgets-block">
			<div class="row">
				<div class="footer-contact">
					
					<?php require_once 'inc/footer/sports-footer-logo.php'; ?>

					<?php require_once 'inc/footer/contact-payment-wrap.php'; ?>
				</div><!-- .footer-contact -->

				<?php require_once 'inc/footer/footer-widgets.php'; ?>
			</div><!-- .row -->
		</div><!-- .footer-widgets-block -->
		
		<?php require_once 'inc/footer/footer-site-info.php'; ?>
	</div><!-- .col-full -->
</footer><!-- .site-footer -->
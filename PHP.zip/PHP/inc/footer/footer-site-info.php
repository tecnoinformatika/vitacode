<div class="site-info">	
	<div class="col-full">
		<div class="copyright">Copyright &copy; 2017 <a href="index.php">Techmarket</a> Theme. All rights reserved.</div><!-- .copyright -->
		<div class="credit">Made with <i class="fa fa-heart"></i> by bcube.</div><!-- .credit -->
	</div><!-- .col-full -->
</div><!-- .site-info -->
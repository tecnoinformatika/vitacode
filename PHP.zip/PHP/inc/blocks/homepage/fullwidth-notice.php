<div class="fullwidth-notice stretch-full-width">
	<div class="col-full">
		<p class="message">Download our new app today! Dont miss our mobile-only offers and shop with Android Play.</p>
	</div><!-- .col-full -->
</div><!-- .fullwidth-notice -->
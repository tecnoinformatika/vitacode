<div class="banner full-width-banner">
	<a href="index.php?page=shop">
		<div style="background-size: cover; background-position: center center; background-image: url( assets/images/organic/organic-banner3.jpg ); height: 236px;" class="banner-bg">
			<div class="caption">
				<div class="banner-info">
					<h3 class="title"><strong>Extremely Portable</strong>, learn <br> to ride in just 3 minutes</h3>
					<h4 class="subtitle">Travel up to 22km in a single charge</h4>				
				</div>
				<span class="banner-action button">Browse now<i class="feature-icon d-flex ml-4 tm tm-long-arrow-right"></i></span>
			</div><!-- /.caption -->
		</div><!-- /.banner-b -->
	</a><!-- /.section-header -->
</div><!-- /.banner -->
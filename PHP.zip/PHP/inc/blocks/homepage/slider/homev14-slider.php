<div class="slider-block column-1">
	<div class="home-v6-slider home-slider" >
		<div class="slider-1">
			<img src="assets/images/garden/tools-banner.jpg" alt="">
			<div class="caption">
				<div class="pre-title">12 Days of Deals </div>
				<div class="title">Brilliant features, brilliant price. Efficient in every way.</div>
				<div class="offer-price">$339.99</div>
				<div class="sale-price">$689</div>
				<div class="button">Browse now <i class="tm tm-long-arrow-right"></i></div>
			</div>
		</div>

		<div class="slider-1">
			<img src="assets/images/garden/tools-banner.jpg" alt="">
			<div class="caption">
				<div class="pre-title">12 Days of Deals </div>
				<div class="title">Brilliant features, brilliant price. Efficient in every way.</div>
				<div class="offer-price">$339.99</div>
				<div class="sale-price">$689</div>
				<div class="button">Browse now <i class="tm tm-long-arrow-right"></i></div>
			</div>
		</div>
	</div>
</div>
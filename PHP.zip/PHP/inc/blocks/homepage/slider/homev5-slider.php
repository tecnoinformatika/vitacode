<div class="slider-block column-1-slider-block">

	<div class="home-v5-slider home-slider" >
		<div class="slider-1">
			<img src="assets/images/slider/home-v5-img-1.png" alt="">
			<div class="caption">
				<div class="title">Records every beat in real-time </div>
				<div class="sub-title">Cardio exercises like aerobics are great for improving heart and lung capacity. </div>
				<div class="button">Browse now <i class="tm tm-long-arrow-right"></i></div>
			</div>
		</div>

		<div class="slider-1">
			<img src="assets/images/slider/home-v5-img-1.png" alt="">
			<div class="caption">
				<div class="title">Records every beat in real-time </div>
				<div class="sub-title">Cardio exercises like aerobics are great for improving heart and lung capacity. </div>
				<div class="button">Browse now <i class="tm tm-long-arrow-right"></i></div>
			</div>
		</div>
	</div>
</div>

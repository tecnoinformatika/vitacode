<div class="landing-v1-slider">
	<div class="slider-1">
		<img src="assets/images/slider/landing-v1-img-1.png" alt="">
		<div class="caption">
			<div class="pre-title">Gaming 4K*</div>
			<div class="title">Desktops & Laptops</div>
			<div class="sub-title">#GamingTechMarket</div>
			<div class="bottom-caption">*Only Desktops PC are for Gaming purposes</div>
		</div>
	</div>
</div>
<div class="home-v10-slider home-slider" >
	<div class="slider-1" style="background-image: url(assets/images/slider/home-v10-background.jpg);">
		<img src="assets/images/slider/home-v10-img-1.png" alt="">
		<div class="caption">
			<div class="pre-title">ONLY IN 4.04-10.04</div>
			<div class="title">WEEKEND SALE</div>
			<div class="sub-title">-20% CUT FOR EVERYTHING*</div>
			<div class="button">Get Yours now <i class="tm tm-long-arrow-right"></i></div>
		</div>
	</div>
</div>
<div class="home-v12-slider home-slider" >
	<div class="slider-1" style="background-image: url(assets/images/slider/home-v12-background.jpg);">
		<div class="caption">
			<div class="pre-title">warehouse</div>
			<div class="title">clear-out</div>
			<div class="sub-title">of fitness home equipment</div>
			<div class="offer-price">up to 70% sale!</div>
			<div class="button">Get Yours now <i class="tm tm-long-arrow-right"></i></div>
			<div class="bottom-caption">Free shipping on US Terority</div>
		</div>
	</div>
</div>


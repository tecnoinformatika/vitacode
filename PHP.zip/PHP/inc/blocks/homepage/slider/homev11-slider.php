<div class="home-v11-slider home-slider" >
	<div class="slider-1" style="background-image: url(assets/images/slider/home-v11-background.jpg);">
		<div class="caption">
			<div class="title">    For a weekend <br>outside the city</div>
			<div class="sub-title">Comfortable set <br> for him</div>
			<div class="button">Get Yours now <i class="tm tm-long-arrow-right"></i></div>
		</div>
	</div>
</div>
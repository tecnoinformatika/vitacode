<div class="landing-v2-slider">
	<div class="slider-1" style="background-image: url(assets/images/slider/landing-v2-background.jpg);">
		<div class="caption">
			<div class="title-left">4K<span>THE NEXT GENERATION IN TV</span></div>
			<div class="title-right">Perfect colors.<br>Boundless designs.<br>Smarter than ever. </div>
		</div>
	</div>
</div>
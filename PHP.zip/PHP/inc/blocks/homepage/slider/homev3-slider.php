<div class="slider">
	<div class="home-v3-slider home-slider" >
		<div class="slider-1">
			<img src="assets/images/slider/home-v3-img-1.png" alt="">
			<div class="caption">
				<div class="title">The new-tech gift you are wishing for<br>is right here</div>
				<div class="sub-title">Big screens in incredibly slim designs that in your hand.</div>
				<div class="button">Browse now <i class="tm tm-long-arrow-right"></i></div>
				<div class="bottom-caption">Free shipping on US Terority</div>
			</div>
		</div>

		<div class="slider-1 slider-2">
			<img src="assets/images/slider/home-v1-img-2.png" alt="">
			<div class="caption">
				<div class="title">The new-tech gift you are wishing for<br>is right here</div>
				<div class="sub-title">Big screens in incredibly slim designs that in your hand.</div>
				<div class="button">Browse now <i class="tm tm-long-arrow-right"></i></div>
				<div class="bottom-caption">Free shipping on US Terority</div>
			</div>
		</div>
	</div>
</div>
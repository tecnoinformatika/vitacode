<div class="home-v9-slider home-slider" >
	<div class="slider-1" style="background-image: url(assets/images/slider/home-v9-background.jpg);">
		<img class= "img-1 " src="assets/images/slider/home-v9-img-1.jpg" alt="">
		<img class= "img-2" src="assets/images/slider/home-v9-img-2.png" alt="">
		<img class= "img-3" src="assets/images/slider/home-v9-img-3.png" alt="">
		<img class= "img-4" src="assets/images/slider/home-v9-img-4.jpg" alt="">
		<div class="caption-button">
			<div class="button-left button">SHOP <span>Women</span></div>
			<div class="button-right button">SHOP <span>men</span></div>
		</div>
	</div>
</div>
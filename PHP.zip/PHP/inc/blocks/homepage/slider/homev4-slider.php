<div class="home-v4-slider home-slider" >
	<div class="slider-1" style="background-image: url(assets/images/slider/home-v4-background.jpg);">
		<div class="caption">
			<div class="title">The gift they are <br>wishing for is right here </div>
			<div class="sub-title">The curved display has a curvature level equivalent to that of a circle, tracks the rounded shape of the eyes better </div>
			<div class="button">Get Yours now <i class="tm tm-long-arrow-right"></i></div>
			<div class="bottom-caption">Free shipping on US Terority</div>
		</div>
	</div>
</div>
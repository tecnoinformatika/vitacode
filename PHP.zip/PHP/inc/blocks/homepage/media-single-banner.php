<div class="media">
	<img alt="" src="assets/images/products/media-banner-1.jpg" class="d-flex align-self-center">
	<div class="media-body">
		<h2 class="section-title">QLED - The Next Generation <br>in Televisions</h2>
		<div class="description">
			<p>Nullam dignissim elit ut urna rutrum, a fermentum mi auctor. Mauris efficitur magna orci, et dignissim lacus scelerisque sit amet. Proin malesuada tincidunt nisl ac commodo. Vivamus eleifend porttitor ex sit amet suscipit. Vestibulum at ullamcorper lacus, vel facilisis arcu. Aliquam erat volutpat.</p>
			<ul>
				<li>High-precision lens provides a clearer picture and a better view for 3D.</li>
				<li>55" class screen full array LED TV</li>
				<li>With stand: 48.98"W x 30.69"H x 10.59"D</li>
				<li>Display type: LED, Resolution: 1920 x 1080, Contrast ratio: 2M:1</li>
				<li>Motion Rate: 120</li>
			</ul>
		</div><!-- .description -->
		<a href="index.php?page=shop" class="button">Show Products</a>
	</div><!-- .media-body -->
</div><!-- .media -->

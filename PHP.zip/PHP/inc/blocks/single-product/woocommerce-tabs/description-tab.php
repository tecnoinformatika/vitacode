<h2>Description</h2>
<h1 style="text-align: center;">Exceptional color. Authentic images.</h1>
<p style="text-align: center;max-width: 1160px;margin: auto auto 60px;">Nullam dignissim elit ut urna rutrum, a fermentum mi auctor. Mauris efficitur magna orci, et dignissim lacus scelerisque sit amet. Proin malesuada tincidunt nisl ac commodo. Vivamus eleifend porttitor ex sit amet suscipit. Vestibulum at ullamcorper lacus, vel facilisis arcu. Aliquam erat volutpat.</p>
<div style="text-align: center;">
	<iframe width="854" height="480" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/K5OGs8a3vlM?ecver=1"></iframe>
</div>

<div class="outer-wrap">
	<div class="content-info">
		<h1 style="text-align: left;">Dynamic brightness<br>
		reveals hidden details</h1>
		<p style="text-align: left;">Nullam dignissim elit ut urna rutrum, a fermentum mi auctor. Mauris efficitur magna orci, et dignissim lacus<br>
		scelerisque sit amet. Proin malesuada tincidunt nisl ac commodo. Vivamus eleifend porttitor ex sit amet suscipit.<br>
		Vestibulum at ullamcorper lacus, vel facilisis arcu. Aliquam erat volutpat.</p>
	</div><!-- .content-info -->

	<div class="image-info">
		<img src="assets/images/products/des1.png" alt="">
	</div><!-- .image-info -->
</div><!-- .outer-wrap -->

<div class="outer-wrap">
	<div class="image-info">
		<img src="assets/images/products/des2.png" class="alignnone" alt="">
	</div><!-- .image-info -->
	
	<div class="content-info">
		<h1 style="text-align: right;">An incredible view,<br>
		wherever you sit</h1>
		<p style="text-align: right;">Nullam dignissim elit ut urna rutrum, a fermentum mi auctor. Mauris efficitur magna orci, et dignissim lacus<br>
		scelerisque sit amet. Proin malesuada tincidunt nisl ac commodo. Vivamus eleifend porttitor ex sit amet suscipit. Vestibulum at ullamcorper lacus, vel facilisis arcu. Aliquam erat volutpat.</p>
	</div><!-- .content-info -->
</div><!-- .outer-wrap -->

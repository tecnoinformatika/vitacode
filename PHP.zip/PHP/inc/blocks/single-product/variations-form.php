 <form enctype="multipart/form-data" method="post" class="cart">
	<div class="quantity buttons_added">
		<input type="button" class="minus" value="-">
		<label for="quantity-input">Quantity</label>
		<input type="number" size="4" class="input-text qty text" title="Qty" value="1" name="quantity" id="quantity-input">
		<input type="button" class="plus" value="+">
	</div><!-- .quantity -->
	<button class="single_add_to_cart_button button alt" value="185" name="add-to-cart" type="submit">Add to cart</button>
</form><!-- .cart -->
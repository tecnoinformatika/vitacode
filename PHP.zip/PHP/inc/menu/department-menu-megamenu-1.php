<ul role="menu" class=" dropdown-menu">

	<li class="menu-item menu-item-object-static_block animate-dropdown">
		<div class="yamm-content">
			
			<div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">

				<div class="kc-col-container">
					<div class="kc_single_image">
						<img src="assets/images/megamenu.jpg" class="" alt=""/>
					</div><!-- .kc_single_image -->
				</div><!-- .kc-col-container -->
						
			</div><!-- .bg-yamm-content -->

			<div class="row yamm-content-row">
			
				<div class="col-md-6 col-sm-12">
					<div class="kc-col-container">
						<div class="kc_text_block">
							<ul>
								<li class="nav-title">Computers &amp; Accessories</li>
								<li><a href="index.php?page=shop">All Computers &amp; Accessories</a></li>
								<li><a href="index.php?page=shop">Laptops, Desktops &amp; Monitors</a></li>
								<li><a href="index.php?page=shop">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
								<li><a href="index.php?page=shop">Printers &amp; Ink</a></li>
								<li><a href="index.php?page=shop">Networking &amp; Internet Devices</a></li>
								<li><a href="index.php?page=shop">Computer Accessories</a></li>
								<li><a href="index.php?page=shop">Software</a></li>
								<li class="nav-divider"></li>
								<li>
									<a href="index.php?page=shop"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a>
								</li>
							</ul>
						</div><!-- .kc_text_block -->
					</div><!-- .kc-col-container -->
				</div><!-- .kc_column -->

				<div class="col-md-6 col-sm-12">
					<div class="kc-col-container">
						<div class="kc_text_block">
							<ul>
								<li class="nav-title">Office &amp; Stationery</li>
								<li><a href="index.php?page=shop">All Office &amp; Stationery</a></li>
								<li><a href="index.php?page=shop">Pens &amp; Writing</a></li>
							</ul>
						</div><!-- .kc_text_block -->
					</div><!-- .kc-col-container -->
				</div><!-- .kc_column -->
					
			</div><!-- .kc_row -->
		</div><!-- .yamm-content -->
	</li>
</ul>
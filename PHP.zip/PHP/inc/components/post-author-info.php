<div class="post-author-info">
	<div class="media">
		<div class="media-left media-middle">
			<a href="#">
				<img src="assets/images/blog/author.jpg" alt="">						
			</a>
		</div><!-- .media-left -->

		<div class="media-body">
			<h4 class="media-heading">
				<a href="#">Jane Smith</a>
			</h4>
		</div><!-- .media-body -->
	</div><!-- .media -->
</div><!-- .post-author-info -->
<nav class="navigation pagination" id="post-navigation">
	<span class="screen-reader-text">Posts navigation</span>
	<div class="nav-links">
		<ul class="page-numbers">
			<li><a href="#" class="page-numbers current">1</a></li>
			<li><span class="page-numbers">2</span></li>
			<li><a href="#" class="next page-numbers">Next</a></li>
		</ul><!-- .page-numbers -->
	</div><!-- .nav-links -->
</nav><!-- .navigation -->
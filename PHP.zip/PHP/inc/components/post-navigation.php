<nav aria-label="Post Navigation" class="navigation post-navigation" id="post-navigation">
	<span class="screen-reader-text">Post navigation</span>
	<div class="nav-links">
		<div class="nav-previous">
			<a rel="prev" href="#">
			<span class="meta-nav">←</span>&nbsp;How to build your first 4k ready Desktop PC</a>
		</div><!-- /.nav-previous -->
		
		<div class="nav-next">
			<a href="#" rel="next">Robot Wars – Now Closed – Post with Gallery &nbsp;
				<span class="meta-nav">→</span>
			</a>
		</div><!-- /.nav-next -->
	</div><!-- /.nav-links -->
</nav><!-- /.post-navigation -->
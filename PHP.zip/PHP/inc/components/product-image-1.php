<?php
$productImage = array(
	1 => array('product_image' => 'assets/images/organic/1.jpg'),
	2 => array('product_image' => 'assets/images/organic/2.jpg'),
	3 => array('product_image' => 'assets/images/organic/3.jpg'),
	4 => array('product_image' => 'assets/images/organic/4.jpg'),
	5 => array('product_image' => 'assets/images/organic/5.jpg'),
	6 => array('product_image' => 'assets/images/organic/6.jpg'),
	7 => array('product_image' => 'assets/images/organic/7.jpg'),
	8 => array('product_image' => 'assets/images/organic/8.jpg'),
	9 => array('product_image' => 'assets/images/organic/9.jpg'),
	10 => array('product_image' => 'assets/images/organic/10.jpg'),
	11 => array('product_image' => 'assets/images/organic/11.jpg'),
	12 => array('product_image' => 'assets/images/organic/12.jpg'),
	13 => array('product_image' => 'assets/images/organic/13.jpg'),
	14 => array('product_image' => 'assets/images/organic/14.jpg'),
	15 => array('product_image' => 'assets/images/organic/15.jpg')
	
	);

?>

<div class="banners home4-banner techmarket-banner">
	<div class="row">
		<div class="banner text-in-right">
			<a href="#">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/4-1.jpg ); height: 484px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">Your Home <br> on every screen <br>imagination</h3>				
						</div><!-- .banner-info -->
						<span class="banner-action button">Check More</span>
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->
		
		<div class="banner text-in-left">
			<a href="#">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/4-2.jpg ); height: 484px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">No worry anymore <br> with Fast Charge</h3><h4 class="subtitle">Discover up to 6000mAh in one device</h4>				
						</div><!-- .banner-info -->
						<span class="banner-action button">Buy Now</span>
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->
	</div><!-- .row -->
</div><!-- .banners -->

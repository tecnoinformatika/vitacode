<div class="banners-block column-2-banners-block">
	<div class="banner text-in-left">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/1-1.png ); height: 204px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title"><strong>20% Off Tech</strong> <br> at Ultrabooks, <br> Laptops, Tablets<br>Notebooks &amp;<br>More</h3>
					</div><!-- .banner-info -->
				</div><!-- .caption -->
			</div><!-- .banner-bg -->
		</a>
	</div><!-- .banner -->

	<div class="banner text-in-left">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/2-1.png ); height: 204px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h4 class="pretitle">Best Gift Idea</h4><h3 class="title">Mini Two Wheel <br><strong>Self Balancing</strong> <br> Scooter</h3>
					</div><!-- .banner-info -->
					<span class="price">
						<ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>339.99</span></ins> 
						<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">£</span>689</span></del>
					</span>
				</div><!-- .caption -->
			</div><!-- .banner-bg -->
		</a>
	</div><!-- .banner -->
</div><!-- .banners-block -->
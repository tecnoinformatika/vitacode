<div class="banner full-width-banner home-v9-full-banner stretch-full-width">
	<a href="index.php?page=shop">
		<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/9-2.jpg ); height: 637px;" class="banner-bg">
			<div class="caption">
				<div class="banner-info">
					<h3 class="title">Woods
						<span><span>G21</span><span><span>Design By</span><br>
						Valentina Doe</span></span>
					</h3>
				</div><!-- .banner-info -->
				<span class="banner-action button">Get yours now<i class="feature-icon d-flex ml-4 tm tm-long-arrow-right"></i></span>
			</div><!-- .caption -->
		</div><!-- .banner-bg -->
	</a>
</div><!-- .banner -->
<div class="banner full-width-banner stretch-full-width help-banner">
	<a href="index.php?page=contact-v1">
		<div style="background-color:#eeeeee; height:495px;" class="banner-bg">
			<div class="caption">
				<div class="banner-info">
					<h4 class="pretitle">Get in Touch</h4>
					<h3 class="title">How can we<br>help you?</h3>
					<h4 class="subtitle">Whether it be to add to your collection, that first special wristwatch or the restoration of a much loved heirloom we are here to help</h4>
				</div><!-- .banner-info -->
			</div><!-- .caption -->
		</div><!-- .banner-bg -->
	</a>
</div><!-- .banner -->
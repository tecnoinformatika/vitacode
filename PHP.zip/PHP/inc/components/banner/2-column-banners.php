<div class="banners">
	<div class="row">
		<div class="banner banner-long text-in-right">
			<a href="#">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/3-2.jpg ); height: 259px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title"><strong>Shop now</strong> to find savings on everything you need<br> for the big game.</h3>				
						</div><!-- /.banner-info -->
						<span class="banner-action button">Browse</span>
					</div><!-- /.caption -->
				</div><!-- /.banner-bg -->
			</a>
		</div><!-- /.banner -->

		<div class="banner banner-short text-in-left">
			<a href="#">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/3-3.jpg ); height: 259px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title"><strong>1000 mAh</strong> <br> Power Bank Pro.</h3>				
						</div><!-- /.banner-info -->
						<span class="price">$34.99</span>
						<span class="banner-action button">Buy Now</span>
					</div><!-- /.caption -->
				</div><!-- /.banner-bg -->
			</a>
		</div><!-- /.banner -->
	</div><!-- /.row -->
</div><!-- /.banners -->
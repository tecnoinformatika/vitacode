<div class="banner full-width-banner text-in-left banners-v2">
	<a href="index.php?page=shop">
		<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/12-8.jpg ); height: 236px;" class="banner-bg">
			<div class="caption">
				<div class="banner-info">
					<h3 class="title"><strong>Seamless entertainment</strong> <br> from start to end</h3><h4 class="subtitle">Discover a world of content</h4>				
				</div><!-- .banner-info -->
				<span class="banner-action button">Browse now<i class="feature-icon d-flex ml-4 tm tm-long-arrow-right"></i></span>
			</div><!-- .caption -->
		</div><!-- .banner-bg -->
	</a>
</div><!-- .banner -->
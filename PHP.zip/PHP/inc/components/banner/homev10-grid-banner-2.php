<div class="banners techmarket-banner techmarket-grid-banner-2">
	<div class="row">
		<div class="banner large-banner text-in-center">
			<a href="index.php?page=shop">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/10-6.jpg ); height: 539px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">Be Nicer <br>For Yourself</h3>				
						</div><!-- .banner-info -->
						<span class="banner-action button">Check Now<i class="tm tm-long-arrow-right"></i></span>
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->

		<div class="banner small-banner text-in-center">
			<a href="index.php?page=shop">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/10-7.jpg ); height: 273px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">&nbsp;</h3>				
						</div><!-- .banner-info -->
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->

		<div class="banner small-banner text-in-center">
			<a href="index.php?page=shop">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/10-8.jpg ); height: 273px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">&nbsp;</h3>				
						</div><!-- .banner-info -->
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->

		<div class="banner large-banner text-in-center">
			<a href="index.php?page=shop">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/10-9.jpg ); height: 544px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">&nbsp;</h3>				
						</div><!-- .banner-info -->
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->
	</div><!-- .row -->
</div><!-- .banners -->
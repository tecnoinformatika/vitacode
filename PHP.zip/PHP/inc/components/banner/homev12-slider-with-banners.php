<div class="banners-block column-2">
	<div class="banner text-in-left">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/12-1.jpg ); height: 210px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title"><strong>Top 100 Deals</strong><br> for Womens<br> Fashion</h3> 
					</div>
						<span class="price"><span class="start_price">Starting at</span><br>$69.99</span>
				</div><!-- .caption -->
			</div>
		</a>
	</div><!-- .banner -->

	<div class="banner text-in-left">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/12-2.jpg ); height: 210px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title">Billboard<br> Music Albums<br> <strong>Carnival</strong> time </h3><h4 class="subtitle">Buy 3 Get 10% off</h4> 
					</div>
				</div><!-- .caption -->
			</div>
		</a>
	</div><!-- .banner -->

	<div class="banner text-in-left">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/12-3.jpg ); height: 210px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title"><strong>20% Off Tech</strong><br> at Smartphones,<br> Power banks, <br>Accesories &amp;<br> More</h3> 
					</div>
				</div><!-- .caption -->
			</div>
		</a>
	</div><!-- .banner -->

	<div class="banner text-in-left">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/12-4.jpg ); height: 210px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h4 class="pretitle">Kids Day</h4><h3 class="title">Limited Free<br> <strong> 2-Day Shipping</strong><br> on Kids products</h3> 
					</div>
				</div>
			</div>
		</a>
	</div><!-- .banner -->
</div><!-- .banners-block -->
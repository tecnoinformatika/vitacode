<div class="banners techmarket-banner col-2-full-width-banner stretch-full-width">
	<div class="row">
		<div class="banner text-in-center">
			<a href="index.php?page=shop">
				<div style="background-color:#cedfe9; height:695px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title"><span>The</span> <br> <strong>Wooden Circle</strong><span>Collection</span></h3>
						</div><!-- .banner-info -->
							<span class="banner-action button">View Collection<i class="tm tm-long-arrow-right"></i></span>
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->

		<div class="banner text-in-center">
			<a href="index.php?page=shop">
				<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/9-1.jpg ); height: 695px;" class="banner-bg">
					<div class="caption">
						<div class="banner-info">
							<h3 class="title">&nbsp;</h3>
						</div><!-- .banner-info -->
					</div><!-- .caption -->
				</div><!-- .banner-bg -->
			</a>
		</div><!-- .banner -->
	</div><!-- .row -->
</div><!-- .banners -->
<div class="shop-control-bar-bottom">
	<form class="form-techmarket-wc-ppp" method="POST">
		<select class="techmarket-wc-wppp-select c-select" onchange="this.form.submit()" name="ppp">
			<option value="20">Show 20</option>
			<option value="40">Show 40</option>
			<option value="-1">Show All</option>
		</select>
		<input type="hidden" value="5" name="shop_columns">
		<input type="hidden" value="15" name="shop_per_page">
		<input type="hidden" value="right-sidebar" name="shop_layout">
	</form><!-- .form-techmarket-wc-ppp -->

	<p class="woocommerce-result-count">
		Showing 1&ndash;15 of 73 results
	</p><!-- .woocommerce-result-count -->
	
	<nav class="woocommerce-pagination">
		<ul class="page-numbers">
			<li><span class="page-numbers current">1</span></li>
			<li><a href="#" class="page-numbers">2</a></li>
			<li><a href="#" class="page-numbers">3</a></li>
			<li><a href="#" class="page-numbers">4</a></li>
			<li><a href="#" class="page-numbers">5</a></li>
			<li><a href="#" class="next page-numbers">→</a></li>
		</ul><!-- .page-numbers -->
	</nav><!-- .woocommerce-pagination -->
</div><!-- .shop-control-bar-bottom -->
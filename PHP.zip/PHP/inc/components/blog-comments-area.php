<div id="comments" class="comments-area">

    <h2 class="comments-title"> 3 Comment</h2>

    <ol class="commentlist">
		<li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
		    <div class="comment_container">
				<img width="100" height="100" class="avatar avatar-100 photo" src="assets/images/blog/author.jpg" alt="">
				<div class="comment-text">
					<div class="meta">
						<strong class="woocommerce-review__author" itemprop="author">Jane Smith</strong>
						<time datetime="2017-03-23T08:06:09+00:00" class="woocommerce-review__published-date">July 24, 2017</time>
					</div>

					<div class="comment-content">
						<div class="description"><p>good</p>
						</div>

						<div class="reply">
							<a class="comment-edit-link" href="#">Edit</a>							
							<a href="index.php?page=blog-single#respond" class="comment-reply-link" rel="nofollow">Reply</a>
						</div><!-- .reply -->
					</div><!-- .comment-content -->
				</div><!-- .comment-text -->
			</div><!-- .comment_container -->
		</li><!-- .comment -->

		<li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
		    <div class="comment_container">
				<img width="100" height="100" class="avatar avatar-100 photo" src="assets/images/blog/author.jpg" alt="">
				<div class="comment-text">
					<div class="meta">
						<strong class="woocommerce-review__author" itemprop="author">Jane Smith</strong>
						<time datetime="2017-03-23T08:06:09+00:00" class="woocommerce-review__published-date">July 24, 2017</time>
					</div>

					<div class="comment-content">
						<div class="description"><p>Awesome</p>
						</div>

						<div class="reply">
							<a class="comment-edit-link" href="#">Edit</a>							
							<a href="index.php?page=blog-single#respond" class="comment-reply-link" rel="nofollow">Reply</a>
						</div><!-- .reply -->
					</div><!-- .comment-content -->
				</div><!-- .comment-text -->
			</div><!-- .comment_container -->
		</li><!-- .comment -->

		<li class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
		    <div class="comment_container">
				<img width="100" height="100" class="avatar avatar-100 photo" src="assets/images/blog/author.jpg" alt="">
				<div class="comment-text">
					<div class="meta">
						<strong class="woocommerce-review__author" itemprop="author">Jane Smith</strong>
						<time datetime="2017-03-23T08:06:09+00:00" class="woocommerce-review__published-date">July 24, 2017</time>
					</div>

					<div class="comment-content">
						<div class="description"><p>Nice</p>
						</div>

						<div class="reply">
							<a class="comment-edit-link" href="#">Edit</a>							
							<a href="index.php?page=blog-single#respond" class="comment-reply-link" rel="nofollow">Reply</a>
						</div><!-- .reply -->
					</div><!-- .comment-content -->
				</div><!-- .comment-text -->
			</div><!-- .comment_container -->
		</li><!-- .comment -->
	</ol><!-- .commentlist -->

    <div class="comment-respond" id="respond">
        <h3 class="comment-reply-title" id="reply-title">Leave a Reply</h3>
        <form novalidate="" class="comment-form" id="commentform" method="post" action="#">
            <p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> Required fields are marked <span class="required">*</span></p><p class="comment-form-comment"><label for="comment">Comment</label> <textarea required="required" maxlength="65525" rows="8" cols="45" name="comment" id="comment"></textarea></p><p class="comment-form-author"><label for="author">Name <span class="required">*</span></label> <input type="text" required="required" aria-required="true" maxlength="245" size="30" value="" name="author" id="author"></p>
            <p class="comment-form-email"><label for="email">Email <span class="required">*</span></label> <input type="email" required="required" aria-required="true" aria-describedby="email-notes" maxlength="100" size="30" value="" name="email" id="email"></p>
            <p class="comment-form-url"><label for="url">Website</label> <input type="url" maxlength="200" size="30" value="" name="url" id="url"></p>
            <p class="form-submit"><input type="submit" value="Post Comment" class="submit"></p>
        </form>
    </div><!-- #respond -->

</div><!-- .comments-area -->

<div class="widget woocommerce widget_product_categories techmarket_widget_product_categories" id="techmarket_product_categories_widget-2">
	<ul class="product-categories ">
		<li class="product_cat">
			<span>Browse Categories</span>
			<ul>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Televisions</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Home Theater &amp; Audio</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Headphones</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Digital Cameras</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Cells &amp; Tablets</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Smartwatches</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Games &amp; Consoles</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Printer</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>TV &amp; Video</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Home Entertainment</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Computers &amp; Laptops</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Notebooks</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Desktop PCs</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Mac Computers</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>All in One PC</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Audio &amp; Music</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>PC Components</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="child-indicator"><i class="fa fa-angle-right"></i></span>Desktop PCs</a></li>
				<li class="cat-item"><a href="index.php?page=product-category"><span class="no-child"></span>Monitors</a></li>
			</ul>
		</li>
	</ul>
</div>
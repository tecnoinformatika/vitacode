<div class="widget woocommerce widget_layered_nav maxlist-more" id="woocommerce_layered_nav-2">
	<span class="gamma widget-title">Brands</span>
	<ul>
		<li class="wc-layered-nav-term ">
		<a href="#">apple</a> <span class="count">(2)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">bosch</a> <span class="count">(1)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">cannon</a> <span class="count">(1)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">connect</a> <span class="count">(1)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">galaxy</a> <span class="count">(3)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">gopro</a> <span class="count">(1)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">kinova</a> <span class="count">(1)</span></li>
		<li class="wc-layered-nav-term " ><a href="#">samsung</a> <span class="count">(1)</span></li>
	</ul>
	
</div><!-- .woocommerce widget_layered_nav -->

<div class="widget woocommerce widget_layered_nav maxlist-more" id="woocommerce_layered_nav-3">
	<span class="gamma widget-title">Color</span>
	<ul>
		<li class="wc-layered-nav-term "><a href="#">Black</a> <span class="count">(4)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Blue</a> <span class="count">(4)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Green</a> <span class="count">(5)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Orange</a> <span class="count">(5)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Red</a> <span class="count">(4)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Yellow</a> <span class="count">(5)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Green</a> <span class="count">(5)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Orange</a> <span class="count">(5)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Red</a> <span class="count">(4)</span></li>
		<li class="wc-layered-nav-term "><a href="#">Yellow</a> <span class="count">(5)</span></li>
	</ul>
	
</div><!-- .woocommerce widget_layered_nav -->
<div class="widget widget_techmarket_features_widget">
	<div class="features-list">
		<div class="features">
			<div class="feature">
				<div class="media">
					<i class="feature-icon d-flex mr-3 tm tm-free-delivery"></i>
					<div class="media-body feature-text"><strong>Free Delivery</strong>from $50</div>
				</div><!-- .media -->
			</div><!-- .feature -->

			<div class="feature">
				<div class="media">
					<i class="feature-icon d-flex mr-3 tm tm-feedback"></i>
					<div class="media-body feature-text"><strong>99 % Customer</strong>Feedbacks</div>
				</div><!-- .media -->
			</div><!-- .feature -->

			<div class="feature">
				<div class="media">
					<i class="feature-icon d-flex mr-3 tm tm-free-return"></i>
					<div class="media-body feature-text"><strong>365 Days </strong>for free return</div>
				</div><!-- .media -->
			</div><!-- .feature -->

			<div class="feature">
				<div class="media">
					<i class="feature-icon d-flex mr-3 tm tm-safe-payments"></i>
					<div class="media-body feature-text"><strong>Payment</strong>Secure System</div>
				</div><!-- .media -->
			</div><!-- .feature -->

			<div class="feature">
				<div class="media">
					<i class="feature-icon d-flex mr-3 tm tm-best-brands"></i>
					<div class="media-body feature-text"><strong>Only Best</strong>Brands</div>
				</div><!-- .media -->
			</div><!-- .feature -->
		</div><!-- .features -->
	</div><!-- .features-list -->
</div><!-- .widget_techmarket_features_widget -->
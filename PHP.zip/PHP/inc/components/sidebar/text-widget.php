<div class="widget widget_text" id="text-2">
	<span class="gamma widget-title">About</span>			
	<div class="textwidget">
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt, erat in malesuada aliquam, est erat faucibus purus, eget viverra nulla sem vitae neque. Quisque id sodales libero.</p>
	</div><!-- .textwidget -->
</div><!-- .widget_text -->
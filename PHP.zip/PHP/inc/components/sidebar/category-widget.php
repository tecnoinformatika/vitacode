<div class="widget widget_categories" id="categories-2">
<span class="gamma widget-title">Categories</span>		
	<ul>
		<li class="cat-item cat-item-53">
			<a href="index.php?page=product-category">Accessories</a>
		</li>

		<li class="cat-item cat-item-101">
			<a href="index.php?page=product-category">Design</a>
		</li>

		<li class="cat-item cat-item-51">
			<a href="index.php?page=product-category">Desktop PCs</a>
		</li>

		<li class="cat-item cat-item-96">
			<a href="index.php?page=product-category">Events</a>
		</li>

		<li class="cat-item cat-item-52">
			<a href="index.php?page=product-category">Laptops</a>
		</li>

		<li class="cat-item cat-item-93">
			<a href="index.php?page=product-category">Links &amp; Quotes</a>
		</li>

		<li class="cat-item cat-item-88">
			<a href="index.php?page=product-category">News</a>
		</li>

		<li class="cat-item cat-item-54">
			<a href="index.php?page=product-category">PC Components</a>
		</li>

		<li class="cat-item cat-item-89">
			<a href="index.php?page=product-category">Social</a>
		</li>

		<li class="cat-item cat-item-102">
			<a href="index.php?page=product-category">Technology</a>
		</li>

		<li class="cat-item cat-item-1">
			<a href="index.php?page=product-category">Uncategorized</a>
		</li>

		<li class="cat-item cat-item-99">
			<a href="index.php?page=product-category">Videos</a>
		</li>
	</ul>
</div><!-- .widget_categories -->
<div class="widget widget_tag_cloud">
	<span class="gamma widget-title">Tags Clouds</span>
	<div class="tagcloud">
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">amazon like</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">Awesome</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">bootstrap</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">buy it</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">clean design</a>
		<a style="font-size: 8pt;" class="tag-cloud-link" href="#">electronics</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">theme</a>
		<a style="font-size: 8pt;" class="tag-cloud-link" href="#">video post format</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">woocommerce</a>
		<a style="font-size: 22pt;" class="tag-cloud-link" href="#">wordpress</a>
	</div><!-- .tagcloud -->
</div><!-- .widget_tag_cloud -->
<div class="widget widget_techmarket_poster_widget" id="techmarket_poster_widget-2">
	<div class="poster">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/poster.jpg ); height: 703px;" class="poster-bg">
				<div class="caption">
					<div class="poster-info">
						<h3 class="title"><strong>Listen in</strong> Brilliant<br> Color via</h3>									
						<span class="price">
						<span>starting at</span><br>$ 34.99</span>
					</div><!-- .poster-info -->

					<div class="poster-caption">
						<span class="poster-action button">Start Buying</span>
						<span class="condition">*limited time <br>offer</span>
					</div><!-- .poster-caption -->
				</div><!-- .caption -->
			</div><!-- .banner-bg -->
		</a>
	</div><!-- .poster -->
</div><!-- .widget_techmarket_poster_widget -->
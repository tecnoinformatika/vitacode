<div class="widget woocommerce widget_price_filter" id="woocommerce_price_filter-2">
	
	<p>
	  <span class="gamma widget-title">Filter by price</span>

	  <div class="price_slider_amount">
			<input id="amount" type="text" placeholder="Min price" data-min="6" value="33" name="min_price" style="display: none;">

			<button class="button" type="submit">Filter</button>
		</div>
		<div id="slider-range" class="price_slider"></div>
</div>
	
<div class="widget widget_techmarket_banner_widget">
	<div class="banner">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/side-1.png ); height: 207px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title"><strong>1000 mAh</strong><br><span>Power Bank Pro</span></h3>
					</div><!-- .banner-info -->
					<span class="price">$ 34.99</span>
					<span class="banner-action button">Buy Now</span>
				</div><!-- .caption -->
			</div><!-- .banner-bg -->
		</a>
	</div><!-- .banner -->
</div><!-- .widget_techmarket_banner_widget -->

<div class="widget widget_techmarket_banner_widget">
	<div class="banner">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/side-2.png ); height: 207px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title">New Arrivals<br> in<strong> Accesories</strong><br> at Best prices</h3>
					</div><!-- .banner-info -->
					<span class="banner-action button">View all</span>
				</div><!-- .caption -->
			</div><!-- .banner-bg -->
		</a>
	</div><!-- .banner -->
</div><!-- .widget_techmarket_banner_widget -->

<div class="widget widget_techmarket_banner_widget">
	<div class="banner">
		<a href="index.php?page=shop">
			<div style="background-size: cover; background-position: center center; background-image: url( assets/images/banner/side-3.png ); height: 207px;" class="banner-bg">
				<div class="caption">
					<div class="banner-info">
						<h3 class="title">Catch Best<br><strong>Deals</strong> on <br>the Curved <br>Soundbars</h3>
					</div><!-- .banner-info -->
					<span class="banner-action button">Browse</span>
				</div><!-- .caption -->
			</div><!-- .banner-bg -->
		</a>
	</div><!-- .banner -->
</div><!-- .widget_techmarket_banner_widget -->
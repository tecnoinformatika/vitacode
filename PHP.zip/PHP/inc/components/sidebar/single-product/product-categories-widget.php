<div id="techmarket_product_categories_widget-2" class="widget woocommerce widget_product_categories techmarket_widget_product_categories">
    <ul class="product-categories category-single">
        <li class="product_cat">
            <ul class="show-all-cat">
                <li class="product_cat"><span class="show-all-cat-dropdown">Show All Categories</span>
                    <ul>
                        <li class="cat-item"><a href="index.php?page=product-category">All in One PC</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Audio & Music</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Cells & Tablets</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Computers & Laptops</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Desktop PCs</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Digital Cameras</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Games & Consoles</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Headphones</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Home Entertainment</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Home Theater & Audio</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Mac Computers</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Monitors</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Notebooks</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">PC Components</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Printer</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Smartwatches</a></li>
                        <li class="cat-item"><a href="index.php?page=product-category">Televisions</a></li>
                    </ul>
                </li>
            </ul>

            <ul>
                <li class="cat-item current-cat"><a href="index.php?page=product-category">TV &amp; Video</a></li>
            </ul>
        </li>
    </ul><!-- .product-categories -->
</div><!-- .techmarket_widget_product_categories -->
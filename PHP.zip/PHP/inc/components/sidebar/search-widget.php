<div class="widget widget_search" id="search-2">
	<form action="#" class="search-form" method="get" role="search">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" name="s" value="" placeholder="Search …" class="search-field">
		</label>
		<input type="submit" value="Search" class="search-submit">
	</form><!-- .search-form -->
</div><!-- .widget_search -->
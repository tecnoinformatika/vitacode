<?php
$productImage = array(
	1 => array('product_image' => 'assets/images/products/1.jpg'),
	2 => array('product_image' => 'assets/images/products/2.jpg'),
	3 => array('product_image' => 'assets/images/products/3.jpg'),
	4 => array('product_image' => 'assets/images/products/4.jpg'),
	5 => array('product_image' => 'assets/images/products/5.jpg'),
	6 => array('product_image' => 'assets/images/products/6.jpg'),
	7 => array('product_image' => 'assets/images/products/7.jpg'),
	8 => array('product_image' => 'assets/images/products/8.jpg'),
	9 => array('product_image' => 'assets/images/products/9.jpg'),
	10 => array('product_image' => 'assets/images/products/10.jpg'),
	11 => array('product_image' => 'assets/images/products/11.jpg'),
	12 => array('product_image' => 'assets/images/products/12.jpg'),
	13 => array('product_image' => 'assets/images/products/13.jpg'),
	14 => array('product_image' => 'assets/images/products/14.jpg'),
	15 => array('product_image' => 'assets/images/products/15.jpg'),
	16 => array('product_image' => 'assets/images/products/16.jpg'),
	17 => array('product_image' => 'assets/images/products/17.jpg'),
	18 => array('product_image' => 'assets/images/products/5.jpg'),
	19 => array('product_image' => 'assets/images/products/12.jpg'),
	20 => array('product_image' => 'assets/images/products/1.jpg'),
	21 => array('product_image' => 'assets/images/products/8.jpg'),
	22 => array('product_image' => 'assets/images/products/13.jpg'),
	23 => array('product_image' => 'assets/images/products/14.jpg'),
	24 => array('product_image' => 'assets/images/products/15.jpg'),
	25 => array('product_image' => 'assets/images/products/16.jpg'),
	

	);

?>

<?php
    $productName = array(
        1 => array('product_name' => 'Smart Watches 3 SWR50'),
        2 => array('product_name' => 'ZenBook 3 Ultrabook 8GB 512SSD W10'),
        3 => array('product_name' => 'On-ear Wireless NXTG'),
        4 => array('product_name' => '4K Action Cam with  Wi-Fi & GPS'),
        5 => array('product_name' => 'XONE Wireless Controller'),
        6 => array('product_name' => 'Gear Virtual Reality 3D with Bluetooth Glasses'),
        7 => array('product_name' => 'Bluetooth on-ear PureBass Headphones'),
        8 => array('product_name' => 'Video & Air Quality Monitor'),
        9 => array('product_name' => 'Watch Stainless with Grey Suture Leather Strap'),
        10 => array('product_name' => 'Xtreme ultimate splashproof  portable speaker'),
        11 => array('product_name' => 'Xtreme ultimate splashproof  portable speaker'),
        12 => array('product_name' => 'Bbd 23-Inch Screen LED-Lit  Monitorss Buds'),
        13 => array('product_name' => 'ZenBook 3 Ultrabook 8GB 512SSD W10'),
        14 => array('product_name' => 'On-ear Wireless NXTG'),
        15 => array('product_name' => '4K Action Cam with  Wi-Fi & GPS'),
        16 => array('product_name' => 'XONE Wireless Controller'),
        17 => array('product_name' => 'Gear Virtual Reality 3D with Bluetooth Glasses'),
        18 => array('product_name' => 'Bluetooth on-ear PureBass Headphones'),
        19 => array('product_name' => 'Video & Air Quality Monitor'),
        20 => array('product_name' => 'Watch Stainless with Grey Suture Leather Strap'),
        21 => array('product_name' => 'On-ear Wireless NXTG'),
        22 => array('product_name' => 'Xtreme ultimate splashproof  portable speaker'),
        23 => array('product_name' => 'Xtreme ultimate splashproof  portable speaker'),
        24 => array('product_name' => 'Xtreme ultimate splashproof  portable speaker'),
        25 => array('product_name' => 'Bbd 23-Inch Screen LED-Lit  Monitorss Buds'),
        
    );
    shuffle($productName);
?>
<div id="content" class="site-content" tabindex="-1">
	<div class="col-full">
		<div class="row">
			<div id="primary" class="content-area">
				<main id="main" class="site-main">
					<?php require_once 'inc/blocks/homepage/slider/homev10-slider.php'; ?>
					
					<?php require_once 'inc/components/banner/homev10-grid-banner.php'; ?>

					<?php require_once 'inc/blocks/homepage/products-carousel-tabs-4.php'; ?>

					<?php require_once 'inc/blocks/homepage/fullwidth-notice.php'; ?>

					<?php require_once 'inc/components/banner/homev10-banner-with-carousel.php'; ?>

					<?php require_once 'inc/blocks/homepage/products-carousel-tabs-5.php'; ?>

					<?php require_once 'inc/components/banner/homev10-grid-banner-2.php'; ?>

					<?php require 'inc/blocks/homepage/brands-carousel.php'; ?>			


				</main><!-- #main -->
			</div><!-- #primary -->
		</div><!-- .row -->
	</div><!-- .col-full -->
</div><!-- #content -->
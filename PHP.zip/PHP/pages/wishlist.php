<div id="content" class="site-content">
	<div class="col-full">
		<div class="row">

			<nav class="woocommerce-breadcrumb">
				<a href="index.php">Home</a>
				<span class="delimiter"><i class="tm tm-breadcrumbs-arrow-right"></i></span>
				Wishlist
			</nav><!-- .woocommerce-breadcrumb -->

			<div id="primary" class="content-area">
				<main id="main" class="site-main" >
					<div class="type-page hentry">
						<header class="entry-header">
							<div class="page-header-caption">
								<h1 class="entry-title">Wishlist</h1>
							</div>
						</header><!-- .entry-header -->

						<?php require_once 'inc/components/wishlist-table.php'; ?>

					</div><!-- .hentry -->
				</main><!-- #main -->
			</div><!-- #primary -->
		</div><!-- .row -->
	</div><!-- .col-full -->
</div><!-- #content -->
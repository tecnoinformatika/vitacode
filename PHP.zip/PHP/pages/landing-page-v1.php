<div id="content" class="site-content" tabindex="-1">
	<div class="col-full">
		<div class="row">
			<div id="primary" class="content-area">
				<main id="main" class="site-main">
					<?php require_once 'inc/blocks/homepage/slider/landing-v1-slider.php'; ?>

					<?php require_once 'inc/blocks/homepage/recent-post-with-categories.php'; ?>
					
					<?php require_once 'inc/blocks/homepage/products-with-image-block.php'; ?>
				</main><!-- #main -->
			</div><!-- #primary -->
		</div><!-- .row -->
	</div><!-- .col-full -->
</div><!-- #content -->